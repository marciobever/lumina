import NovoPerfilForm from "../_components/NovoPerfilForm";

export default function Page() {
  return (
    <main className="container py-10">
      <h1 className="text-2xl font-semibold mb-4">Novo Perfil</h1>
      <NovoPerfilForm />
    </main>
  );
}