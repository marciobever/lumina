import AdminDashboard from "./AdminDashboard";
export default function Page() {
  return <AdminDashboard />;
}