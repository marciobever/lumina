// components/WhatsAppCTA.tsx
export default function WhatsAppCTA({ phone, message }:{ phone:string; message?:string }) {
  const href = `https://wa.me/${phone.replace(/\D/g,'')}${message ? `?text=${encodeURIComponent(message)}` : ''}`
  return (
    <a href={href} target="_blank" rel="noreferrer" className="card p-4 flex items-center justify-between gap-4">
      <div>
        <div className="font-semibold">Fale conosco no WhatsApp</div>
        <div className="text-sm text-white/70">Respostas rápidas e suporte editorial.</div>
      </div>
      <div>
        <button className="btn btn-primary">Conversar</button>
      </div>
    </a>
  )
}