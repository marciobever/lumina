'use client'

type Props = {
  display_name: string
  sector?: string | null
  sector_label?: string | null // <- label pronto (ex: "Finanças")
  headline?: string | null
  short_bio?: string | null
  city?: string | null
  tags?: string[] | null
  hero_url?: string | null
  avatar_url?: string | null
}

export default function ProfileHeader({
  display_name,
  sector,
  sector_label,
  headline,
  short_bio,
  city,
  tags,
  hero_url,
  avatar_url,
}: Props) {
  const cover = hero_url || avatar_url || ''
  const avatar = avatar_url || hero_url || '/images/placeholder-600x800.jpg' // garanta esse arquivo no /public/images

  return (
    <section className="section pt-6">
      <div className="container">
        <div className="relative overflow-hidden rounded-2xl border border-white/10 bg-white/[0.03]">
          <div className="absolute inset-0">
            {cover ? (
              <img
                src={cover}
                alt={display_name}
                className="w-full h-full object-cover"
                style={{ filter: 'blur(8px) saturate(1.05) brightness(0.75)' }}
              />
            ) : (
              <div className="w-full h-full bg-gradient-to-br from-slate-800 to-slate-900" />
            )}
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/25 to-transparent" />
          </div>

          <div className="relative grid md:grid-cols-[160px_1fr] gap-4 md:gap-6 p-4 md:p-6">
            <div className="rounded-2xl overflow-hidden border border-white/10 bg-white/[0.06] aspect-[3/4]">
              <img src={avatar} alt={display_name} className="w-full h-full object-cover" />
            </div>

            <div className="flex flex-col gap-3 md:gap-4">
              <div className="flex flex-wrap items-center gap-2">
                {(sector_label || sector) && (
                  <span className="pc-sector">{sector_label ?? sector}</span>
                )}
              </div>

              <h1 className="h-hero text-3xl md:text-5xl">{display_name}</h1>

              {(headline || short_bio) && (
                <p className="text-white/85 text-base md:text-lg max-w-3xl">
                  {headline || short_bio!}
                </p>
              )}

              <div className="flex flex-wrap gap-2 pt-1">
                {city && <span className="pc-chip">{city}</span>}
                {(tags ?? []).slice(0, 6).map((t) => (
                  <span key={t} className="pc-chip pc-chip-dim">#{t}</span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}