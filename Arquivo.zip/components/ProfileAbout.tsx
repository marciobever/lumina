type Props = { text?: string | null }

export default function ProfileAbout({ text }: Props) {
  return (
    <div className="card p-4 md:p-5">
      <h2 className="h-section mb-2">Sobre</h2>
      <p className="text-white/80 leading-relaxed">
        {text ||
          'Perfil editorial focado em nichos fortes de negócio e conteúdo orientado a performance.'}
      </p>
    </div>
  )
}