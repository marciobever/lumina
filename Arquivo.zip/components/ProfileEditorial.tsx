// components/ProfileEditorial.tsx
import React from "react"
import type { NormalizedArticle as NormalizedArticleFromAdapter } from "@/lib/adapters/article"

/** Tipos de blocos que esperamos receber */
type ParagraphBlock = { type: "paragraph"; text: string }
type TipsBlock      = { type: "tips"; title?: string; items: string[] }
type CtaBlock       = { type: "cta"; headline?: string; text?: string; button?: string }
type ArticleBlock   = ParagraphBlock | TipsBlock | CtaBlock

export type NormalizedArticle = NormalizedArticleFromAdapter | {
  hook?: string
  content: ArticleBlock[]
}

/* ---------- Partes ---------- */

const Paragraph = ({ text, dropcap = false }: { text: string; dropcap?: boolean }) => (
  <p className={`reading-loose ${dropcap ? "dropcap" : ""}`}>{text}</p>
)

const Tips = ({ title, items }: { title?: string; items: string[] }) => (
  <div className="my-6 rounded-2xl border border-white/10 bg-white/[0.03] p-5">
    <h3 className="flex items-center gap-2 text-xl font-display font-semibold text-white text-balance">
      <svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="20" height="20"
           fill="none" stroke="currentColor" strokeWidth="2">
        <path d="M9 18h6" /><path d="M10 22h4" />
        <path d="M2 11a10 10 0 1 1 20 0c0 3-1.5 4.5-3.5 6.5S17 20 17 20H7s0-2-.5-2.5S2 14 2 11Z"/>
      </svg>
      {title || "Dicas práticas"}
    </h3>
    <ul className="mt-3 list-disc pl-5 space-y-2 text-white/90">
      {items.map((item, i) => <li key={i} className="reading-loose">{item}</li>)}
    </ul>
  </div>
)

const Cta = ({ headline, text, button }: { headline?: string; text?: string; button?: string }) => (
  <div
    className="mt-8 rounded-2xl p-6 text-center"
    style={{ background: "linear-gradient(45deg, rgba(var(--accent),0.10), rgba(var(--accent2),0.10))" }}
  >
    {headline && <h4 className="text-2xl font-display font-bold text-white text-balance">{headline}</h4>}
    {text && <p className="mt-3 mx-auto max-w-xl text-white/80 reading-loose">{text}</p>}
    {button && (
      <div className="mt-6">
        {/* Abre o bloco #quiz na própria página (CSS :target já está no page.tsx) */}
        <a href="#quiz" className="btn btn-primary px-6">{button}</a>
      </div>
    )}
  </div>
)

/* ---------- Componente principal ---------- */

export default function ProfileEditorial({ article }: { article: NormalizedArticle | null }) {
  if (!article || !Array.isArray(article.content) || article.content.length === 0) return null

  const blocks: React.ReactNode[] = []

  article.content.forEach((block, idx) => {
    if (!block || typeof (block as any).type !== "string") return

    switch (block.type) {
      case "paragraph": {
        const raw = String((block as ParagraphBlock).text ?? "").trim()
        if (!raw) break
        // separa por linhas em branco e remove espaços
        const parts = raw.split(/\n{2,}/).map(s => s.trim()).filter(Boolean)
        parts.forEach((pText, pi) => {
          blocks.push(
            <Paragraph key={`p-${idx}-${pi}`} text={pText} dropcap={idx === 0 && pi === 0} />
          )
        })
        break
      }
      case "tips": {
        const { title, items } = block as TipsBlock
        const list = Array.isArray(items) ? items.map(String).filter(Boolean) : []
        if (list.length) blocks.push(<Tips key={`t-${idx}`} title={title} items={list} />)
        break
      }
      case "cta": {
        const b = block as CtaBlock
        if (b.headline || b.text || b.button) blocks.push(<Cta key={`c-${idx}`} {...b} />)
        break
      }
      default:
        break
    }
  })

  if (blocks.length === 0) return null

  return (
    <section className="card px-6 md:px-8 py-7 md:py-9">
      <h2 className="h-section text-balance">Editorial</h2>

      {article.hook ? (
        <blockquote className="quote-glow mt-5 px-5 py-4 italic text-white/80 reading-loose">
          {article.hook}
        </blockquote>
      ) : null}

      {/* Medida de leitura + tipografia refinada */}
      <div className="mt-6 mx-auto reading-measure prose prose-invert prose-dark text-lg hyphens-auto">
        {blocks}
      </div>
    </section>
  )
}