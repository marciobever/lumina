// app/perfis/page.tsx
import AdSlot from '@/components/AdSlot'
import FiltersBar from '@/components/FiltersBar'
import ProfileCard from '@/components/ProfileCard'
import Pagination from '@/components/Pagination'
import { listProfiles } from '@/lib/queries'
import React from 'react'

export const metadata = {
  title: 'Perfis • LUMINA',
  description:
    'Especialistas em finanças, arquitetura, tecnologia, saúde, jurídico e mais — curadoria editorial.',
}

type Props = { searchParams?: { page?: string } }

export default async function PerfisPage({ searchParams }: Props) {
  const page = Number(searchParams?.page ?? '1')

  // Regra: 11 perfis + 1 ad = 12 itens SEMPRE.
  const PER_PAGE_WITHOUT_AD = 11
  const REQUEST_SIZE = PER_PAGE_WITHOUT_AD + 1 // pega 12 do backend p/ lookahead

  const { data } = await listProfiles({ page, pageSize: REQUEST_SIZE })

  // Garante que só 11 perfis entram na grade
  const profiles = data.slice(0, PER_PAGE_WITHOUT_AD)

  // Insere 1 ad DEPOIS do 6º card (ajusta se tiver menos)
  const insertAfter = Math.min(6, profiles.length) // índice 6 = depois do sétimo item visual
  const grid: Array<{ kind: 'profile'; p: any } | { kind: 'ad' }> = [
    ...profiles.slice(0, insertAfter).map((p: any) => ({ kind: 'profile' as const, p })),
    { kind: 'ad' as const },
    ...profiles.slice(insertAfter).map((p: any) => ({ kind: 'profile' as const, p })),
  ]

  // Paginação: há próxima página se recebemos REQUEST_SIZE itens do backend
  const hasNext = data.length === REQUEST_SIZE

  return (
    <div className="relative">
      {/* Leaderboard topo */}
      <div className="container pt-6">
        <AdSlot id="ad-leaderboard-top" label="Leaderboard Topo" size="728x90 • responsivo" variant="leaderboard" />
      </div>

      {/* Título + filtros */}
      <section className="section">
        <div className="container">
          <div className="mb-5 md:mb-6">
            <h1 className="h-hero text-3xl md:text-5xl">Perfis de Especialistas</h1>
            <p className="text-white/75 mt-2">
              Finanças, arquitetura, tecnologia, saúde, jurídico, educação e mais — descubra referências por nicho.
            </p>
          </div>
          <FiltersBar />
        </div>
      </section>

      {/* Grade + Skyscraper (Desktop) */}
      <section className="pb-10">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-[1fr_300px] gap-6">
            {/* Coluna principal */}
            <div className="min-w-0">
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                {grid.map((item, i) => (
                  <div key={i} className="card-aspect">
                    {item.kind === 'ad' ? (
                      <AdSlot id="ad-native-1" label="Publicidade" variant="native-card" />
                    ) : (
                      <ProfileCard p={item.p} />
                    )}
                  </div>
                ))}
              </div>

              {/* Paginação */}
              <div className="mt-8">
                <Pagination page={page} hasNext={hasNext} />
              </div>
            </div>

            {/* Lateral (só em lg+) */}
            <aside className="hidden lg:block">
              <div className="sticky top-24">
                <AdSlot id="ad-skyscraper" label="Skyscraper" size="300x600" variant="skyscraper" />
              </div>
            </aside>
          </div>
        </div>
      </section>
    </div>
  )
}