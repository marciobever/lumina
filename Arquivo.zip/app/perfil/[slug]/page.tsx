// app/perfil/[slug]/page.tsx
import { notFound } from "next/navigation"
import AdSlot from "@/components/AdSlot"

import ProfileHeader from "@/components/ProfileHeader"
import ProfileAbout from "@/components/ProfileAbout"
import ProfileSimilarBlock from "@/components/ProfileSimilarBlock"
import ProfileEditorial from "@/components/ProfileEditorial"
import { normalizeArticle } from "@/lib/adapters/article"

import {
  getProfileBySlug,
  getProfilePhotos,
  getProfileQuiz,
  listSimilarProfiles,
} from "@/lib/queries"

export const revalidate = 60

/* ================== helpers ================== */
const sectorLabel: Record<string, string> = {
  financas: "Finanças",
  arquitetura: "Arquitetura",
  tecnologia: "Tecnologia",
  marketing: "Marketing",
  saude: "Saúde",
  juridico: "Jurídico",
  educacao: "Educação",
  imobiliario: "Imobiliário",
  estetica: "Estética",
}

const parseMaybe = <T,>(v: any, fallback: T): T => {
  if (v == null) return fallback
  if (typeof v === "string") {
    // Postgres text[] "{a,b,c}" → string[]
    if (v.startsWith("{") && v.endsWith("}")) {
      const arr = v.slice(1, -1).split(",").map((s) => s.trim().replace(/^"(.*)"$/, "$1"))
      return arr as unknown as T
    }
    try { return JSON.parse(v) as T } catch { return fallback }
  }
  return v as T
}

type PhotoItem = { image_url: string; alt?: string }

/* ---- URL guards ---- */
const isGoodUrl = (u: any): u is string =>
  typeof u === "string" && u.length > 6 && /^https?:\/\//i.test(u) && !u.includes("about:blank")
const cleanUrls = (arr: any[]): string[] => (arr || []).map(String).filter(isGoodUrl)

/** Garante grid cheio (8+) aceitando vários formatos de origem */
function buildGallery(opts: {
  apiPhotos?: Array<PhotoItem | { url: string } | string> | null
  gallery_urls?: string[] | string | null
  hero_url?: string | null
  avatar_url?: string | null
  cover_url?: string | null
  display_name: string
  min?: number
}) {
  const { apiPhotos, gallery_urls, hero_url, avatar_url, cover_url, display_name, min = 8 } = opts

  // normaliza apiPhotos → PhotoItem[]
  let fromApi: PhotoItem[] = []
  if (Array.isArray(apiPhotos)) {
    fromApi = apiPhotos
      .map((it: any, i: number) => {
        if (!it) return null
        if (typeof it === "string" && isGoodUrl(it)) return { image_url: it, alt: `${display_name} — ${i + 1}` }
        if (it.image_url && isGoodUrl(it.image_url)) return { image_url: String(it.image_url), alt: it.alt ?? `${display_name} — ${i + 1}` }
        if (it.url && isGoodUrl(it.url))             return { image_url: String(it.url),       alt: it.alt ?? `${display_name} — ${i + 1}` }
        return null
      })
      .filter(Boolean) as PhotoItem[]
  }

  // normaliza gallery_urls (string JSON, text[] ou array)
  const galleryArr = parseMaybe<string[]>(gallery_urls ?? [], [])
  const fromGallery: PhotoItem[] = Array.isArray(galleryArr)
    ? cleanUrls(galleryArr).map((url, i) => ({ image_url: url, alt: `${display_name} — ${i + 1}` }))
    : []

  // fallbacks (hero/avatar/cover) só se válidos
  const fallbacks = cleanUrls([hero_url, avatar_url, cover_url])
  let photos: PhotoItem[] =
    fromApi.length > 0 ? fromApi
    : fromGallery.length > 0 ? fromGallery
    : fallbacks.length
      ? fallbacks.map((u, i) => ({ image_url: u, alt: `${display_name} — ${i + 1}` }))
      : []

  // garante mínimo (repetindo ordenadamente)
  if (photos.length > 0 && photos.length < min) {
    const out: PhotoItem[] = []
    for (let i = 0; i < min; i++) out.push(photos[i % photos.length])
    photos = out
  }

  const images = photos.map((p) => p.image_url).filter(isGoodUrl)
  return { photos, images }
}

/* ====== Quiz normalization ====== */
type NormalizedQuiz = {
  title: string
  description?: string
  questions: Array<{ id: string; title: string; options: string[] }>
}

const QUIZ_DEFAULT_OPTIONS = [
  "Discordo totalmente",
  "Discordo",
  "Neutro",
  "Concordo",
  "Concordo totalmente",
]

// pega o título de várias formas; se tudo falhar, tenta o primeiro valor string do objeto
const pickTitle = (it: any, i: number) => {
  const t =
    it?.title ??
    it?.question ??
    it?.text ??
    it?.label ??
    it?.pergunta ??
    null

  if (t != null && String(t).trim()) return String(t)

  if (it && typeof it === "object") {
    const firstStr = Object.values(it).find((v) => typeof v === "string" && v.trim())
    if (typeof firstStr === "string") return firstStr
  }
  return `Pergunta ${i + 1}`
}

function normalizeQuiz(raw: any): NormalizedQuiz | null {
  if (!raw) return null
  const q = parseMaybe<any>(raw, null)
  if (!q) return null

  // 1) questions: [...]
  if (Array.isArray(q.questions) && q.questions.length > 0) {
    const first = q.questions[0]
    // objetos
    if (first && typeof first === "object") {
      return {
        title: String(q.title ?? "Quiz"),
        description: q.description ? String(q.description) : undefined,
        questions: q.questions.map((it: any, i: number) => ({
          id: String(it?.id ?? `q${i + 1}`),
          title: pickTitle(it, i),
          options: Array.isArray(it?.options) && it.options.length ? it.options.map(String) : QUIZ_DEFAULT_OPTIONS,
        })),
      }
    }
    // strings
    if (typeof first === "string") {
      return {
        title: String(q.title ?? "Quiz"),
        description: q.description ? String(q.description) : undefined,
        questions: q.questions.map((text: string, i: number) => ({
          id: `q${i + 1}`,
          title: String(text),
          options: QUIZ_DEFAULT_OPTIONS,
        })),
      }
    }
  }

  // 2) items: [...]
  if (Array.isArray(q.items) && q.items.length > 0) {
    return {
      title: String(q.title ?? "Quiz"),
      description: q.description ? String(q.description) : undefined,
      questions: q.items.map((it: any, i: number) => ({
        id: String(it?.id ?? `q${i + 1}`),
        title: pickTitle(it, i),
        options: Array.isArray(it?.options) && it.options.length ? it.options.map(String) : QUIZ_DEFAULT_OPTIONS,
      })),
    }
  }

  return null
}

/* ================== SEO ================== */
export async function generateMetadata({ params }: { params: { slug: string } }) {
  const p = await getProfileBySlug(params.slug)
  if (!p) return { title: "Perfil não encontrado • LUMINA" }

  const articleRaw = (p as any).article
  const article = parseMaybe<any>(articleRaw, {})
  const meta = parseMaybe<any>((p as any).seo, {}) || parseMaybe<any>(article?.seo, {})

  const title = meta?.meta_title || `${(p as any).display_name ?? (p as any).name ?? p.slug} • LUMINA`
  const desc  = meta?.meta_description || (p as any).short_bio || (p as any).headline || "Perfil editorial — especialistas por nicho."
  const image = (p as any).hero_url || (p as any).avatar_url || p.cover_url || undefined

  return { title, description: desc, openGraph: { title, description: desc, images: image ? [{ url: image }] : undefined } }
}

/* ================== Página ================== */
export default async function PerfilPage({ params }: { params: { slug:string } }) {
  const p = await getProfileBySlug(params.slug)
  if (!p) notFound()

  const sectorText = p.sector ? (sectorLabel[p.sector] ?? p.sector) : undefined

  const [photosRes, quizRes, similarRes] = await Promise.allSettled([
    getProfilePhotos(p.id),
    getProfileQuiz(p.id),
    listSimilarProfiles(p.id, Array.isArray((p as any).tags) ? (p as any).tags : (p as any).keywords ?? []),
  ])

  const apiPhotos = photosRes.status === "fulfilled" ? photosRes.value : []
  const quizApi   = quizRes.status   === "fulfilled" ? quizRes.value   : null
  const similar   = (similarRes.status === "fulfilled" && Array.isArray(similarRes.value)) ? similarRes.value : []

  const { images } = buildGallery({
    apiPhotos,
    gallery_urls: (p as any).gallery_urls,
    hero_url: (p as any).hero_url ?? null,
    avatar_url: (p as any).avatar_url ?? null,
    cover_url: p.cover_url ?? null,
    display_name: (p as any).display_name ?? (p as any).name ?? p.slug,
    min: 8,
  })

  const article = normalizeArticle((p as any).article)
  const quiz: NormalizedQuiz | null =
    normalizeQuiz(quizApi) ??
    normalizeQuiz((p as any).quiz)

  return (
    <div className="relative min-h-screen">
      {/* Regras do toggle sem JS: quiz escondido até #quiz na URL */}
      <style>{`
        #quiz { display: none; }
        #quiz:target { display: block; }
      `}</style>

      {/* AD topo */}
      <div className="container pt-8 pb-4">
        <AdSlot id="ad-leaderboard-top" label="" size="728x90 • responsivo" variant="leaderboard" />
      </div>

      {/* HEADER */}
      <ProfileHeader
        display_name={(p as any).display_name ?? (p as any).name ?? p.slug}
        sector={p.sector}
        sector_label={sectorText}
        headline={(p as any).headline ?? p.title}
        short_bio={(p as any).short_bio ?? p.bio}
        city={(p as any).city ?? null}
        tags={Array.isArray((p as any).tags) ? (p as any).tags : (p as any).keywords ?? []}
        hero_url={(p as any).hero_url ?? p.cover_url}
        avatar_url={(p as any).avatar_url ?? null}
      />

      {/* meta leve */}
      <div className="container mt-6 mb-10">
        <div className="text-base text-white/60">
          {sectorText ? <span className="font-medium text-white/90">{sectorText}</span> : null}
          {(p as any).city ? <span className="ml-3">• {(p as any).city}</span> : null}
        </div>
      </div>

      <div className="pb-16">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-[1fr_300px] gap-8">
            {/* Principal */}
            <div className="min-w-0 space-y-10">
              {/* SOBRE */}
              <section className="card px-6 md:px-8 py-7 md:py-9">
                <h2 className="text-2xl font-semibold text-white/95 mb-6">Sobre</h2>
                <div className="prose prose-invert max-w-none">
                  <ProfileAbout text={(p as any).short_bio || p.bio} />
                </div>
              </section>

              {/* EDITORIAL — importante: o CTA dentro do componente deve ter href="#quiz" */}
              <ProfileEditorial article={article} />

              {/* GALERIA */}
              <section className="card px-6 md:px-8 py-7 md:py-9">
                <h2 className="text-2xl font-semibold text-white/95 mb-6">Galeria</h2>
                {images?.length ? (
                  <>
                    <div className="mt-6 gallery-grid">
                      {images.slice(0, 8).map((src, i) => (
                        <figure key={i} className="gallery-item img-smooth aspect-square group overflow-hidden rounded-2xl">
                          <div className="absolute inset-0 bg-white/[0.04] animate-pulse" />
                          <div
                            className="gallery-img transition-transform duration-500 group-hover:scale-110"
                            style={{ backgroundImage: `url("${src.replace(/"/g, '\\"')}")` }}
                            aria-label={`Foto ${i + 1}`}
                          />
                        </figure>
                      ))}
                    </div>
                    <p className="mt-5 text-xs text-white/40 italic">* Visual PG-13 — sem clique.</p>
                  </>
                ) : (
                  <p className="mt-2 text-white/60 text-base">Sem imagens disponíveis.</p>
                )}
              </section>

              {/* QUIZ — embutido; abre ao clicar no CTA (href="#quiz") */}
              {quiz && quiz.questions?.length ? (
                <section id="quiz" className="card px-6 md:px-8 py-7 md:py-9 scroll-mt-24">
                  <h2 className="text-2xl font-semibold text-white/95 mb-3">{quiz.title || "Quiz"}</h2>
                  {quiz.description ? (
                    <p className="text-base text-white/70 leading-relaxed mb-8">{quiz.description}</p>
                  ) : null}

                  <div className="space-y-8">
                    <ol className="space-y-7">
                      {quiz.questions.map((q, qi) => (
                        <li key={q.id} className="rounded-2xl border border-white/8 bg-white/[0.02] p-5 md:p-6 transition-all hover:bg-white/[0.03] hover:border-white/12">
                          <div className="flex items-start gap-4 mb-5">
                            <span className="inline-flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-full bg-white/[0.08] border border-white/[0.15] text-base font-bold text-white/95">
                              {qi + 1}
                            </span>
                            <h3 className="text-base font-medium text-white/95 leading-relaxed pt-2">{q.title}</h3>
                          </div>
                          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 md:pl-14">
                            {q.options.map((opt, oi) => {
                              const id = `${q.id}-${oi}`
                              return (
                                <label key={id} htmlFor={id} className="relative cursor-pointer">
                                  <input id={id} type="radio" name={q.id} className="peer sr-only" />
                                  <div className="px-4 py-3 rounded-xl border border-white/8 bg-white/[0.04] text-white/75 text-center
                                                  hover:bg-white/[0.06] hover:border-white/12 transition-all shadow-sm
                                                  peer-checked:border-transparent
                                                  peer-checked:text-white
                                                  peer-checked:shadow-lg
                                                  peer-checked:font-medium
                                                  peer-checked:[background:linear-gradient(90deg,rgba(var(--accent),0.95),rgba(var(--accent2),0.95))]">
                                    <span className="text-sm leading-tight">{opt}</span>
                                  </div>
                                </label>
                              )
                            })}
                          </div>
                        </li>
                      ))}
                    </ol>
                    <div className="flex justify-center pt-4">
                      <button className="btn btn-primary px-10 py-4 text-base font-semibold shadow-xl hover:shadow-2xl transition-all hover:scale-105">
                        Enviar respostas
                      </button>
                    </div>
                  </div>
                </section>
              ) : null}

              {/* SEMELHANTES */}
              {similar.length > 0 ? (
                <section className="card px-6 md:px-8 py-7 md:py-9">
                  <h2 className="text-2xl font-semibold text-white/95 mb-6">Perfis semelhantes</h2>
                  <div className="mt-6">
                    <ProfileSimilarBlock items={similar} />
                  </div>
                </section>
              ) : null}
            </div>

            {/* Lateral */}
            <aside className="hidden lg:block">
              <div className="sticky top-24 space-y-8">
                <AdSlot id="ad-skyscraper-profile" label="" size="300x600" variant="skyscraper" />
                <AdSlot id="ad-rectangle-side" label="" size="300x250" variant="leaderboard" />
              </div>
            </aside>
          </div>
        </div>
      </div>
    </div>
  )
}