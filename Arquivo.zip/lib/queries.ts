// lib/queries.ts
import { db } from './supabaseServer'

/**
 * Importante: a tabela está no schema "lumina".
 * Usamos "lumina.profiles" para garantir que não caia no schema public.
 */
const TABLE = 'profiles'

// ---------- Tipos ----------
export type Profile = {
  id: string
  slug: string
  display_name: string
  title: string | null
  sector: string | null
  city: string | null
  bio: string | null
  headline: string | null
  short_bio: string | null
  cover_url: string | null
  avatar_url: string | null
  hero_url: string | null
  gallery_urls: string[] | null
  tags: string[] | null
  status: 'draft' | 'published'
  exibir_anuncios: boolean | null
  ad_slot_topo: string | null
  ad_slot_meio: string | null
  ad_slot_rodape: string | null
  article: any | null
  quiz: any | null
  seo: any | null
  created_at: string
  updated_at: string
}

// ---------- Helpers ----------
function first<T>(arr?: T[] | null): T | null {
  return Array.isArray(arr) && arr.length ? (arr[0] as T) : null
}

/** Normaliza setor para bater no seu mapa sem acentos (financas, saude, etc.) */
export function normalizeSectorKey(raw?: string | null) {
  if (!raw) return ''
  return raw
    .toLowerCase()
    .normalize('NFD')
    // remove diacríticos
    .replace(/\p{Diacritic}/gu, '')
    // troca espaços por hífen opcionalmente (se precisar)
    .replace(/\s+/g, '-')
}

// ============== Funções usadas pela página ==============

// 1) Perfil por slug
export async function getProfileBySlug(slug: string): Promise<Profile | null> {
  const supa = db()
  const { data, error } = await supa
    .from(TABLE)
    .select('*')
    .eq('slug', slug)
    // .eq('status', 'published') // habilite quando quiser filtrar apenas publicados
    .limit(1)
    .maybeSingle()

  if (error) throw error
  return data as Profile | null
}

// 2) Fotos do perfil (usa o próprio array gallery_urls + cover/avatar como fallback)
export async function getProfilePhotos(profileId: string): Promise<{ image_url: string; alt?: string }[]> {
  const supa = db()
  const { data, error } = await supa
    .from(TABLE)
    .select('display_name, cover_url, avatar_url, gallery_urls')
    .eq('id', profileId)
    .maybeSingle()

  if (error) throw error
  if (!data) return []

  const name = data.display_name as string
  const urls = (data.gallery_urls as string[] | null) ?? []
  const base: string[] = urls.length
    ? urls
    : [data.cover_url, data.avatar_url].filter(Boolean) as string[]

  return base.map((u, i) => ({ image_url: u, alt: `${name} — ${i + 1}` }))
}

// 3) Quiz do perfil (normaliza para o formato esperado pela UI)
export async function getProfileQuiz(profileId: string): Promise<{
  title: string
  description?: string
  questions: { q: string; options?: string[] }[]
} | null> {
  const supa = db()
  const { data, error } = await supa
    .from(TABLE)
    .select('quiz')
    .eq('id', profileId)
    .maybeSingle()

  if (error) throw error
  const q = (data as any)?.quiz
  if (!q) return null

  // Aceita dois formatos:
  // a) array simples de perguntas (strings)
  if (Array.isArray(q)) {
    return {
      title: 'Quiz',
      questions: q.map((s: string) => ({ q: String(s) })),
    }
  }
  // b) objeto completo
  if (q?.questions && Array.isArray(q.questions)) {
    return {
      title: q.title ?? 'Quiz',
      description: q.description ?? '',
      questions: q.questions.map((x: any) =>
        typeof x === 'string'
          ? ({ q: x })
          : ({ q: x.q ?? String(x), options: x.options ?? undefined })
      ),
    }
  }

  return null
}

// 4) “Semelhantes” por tags (ou últimos publicados quando não há tags)
export async function listSimilarProfiles(profileId: string, tags: string[] = [], limit = 6) {
  const supa = db()

  if (!tags?.length) {
    const { data, error } = await supa
      .from(TABLE)
      .select('id, slug, display_name, title, sector, cover_url, avatar_url, hero_url, tags')
      .neq('id', profileId)
      .eq('status', 'published')
      .order('created_at', { ascending: false })
      .limit(limit)

    if (error) throw error
    return data ?? []
  }

  const { data, error } = await supa
    .from(TABLE)
    .select('id, slug, display_name, title, sector, cover_url, avatar_url, hero_url, tags')
    .neq('id', profileId)
    .eq('status', 'published')
    .overlaps('tags', tags)
    .order('created_at', { ascending: false })
    .limit(limit)

  if (error) throw error
  return data ?? []
}

// ============== Outros utilitários (lista/paginado/destaques) ==============

export type ListParams = {
  page?: number
  perPage?: number
  q?: string
  sector?: string
  adsOnly?: boolean
  status?: 'draft' | 'published'
}

export async function listProfiles(params: ListParams = {}) {
  const supa = db()
  const page = Math.max(1, params.page ?? 1)
  const perPage = Math.min(50, Math.max(1, params.perPage ?? 12))
  const from = (page - 1) * perPage
  const to = from + perPage - 1

  let q = supa
    .from(TABLE)
    .select(`
      id, slug, display_name, title, sector, city, bio,
      cover_url, gallery_urls, tags, status,
      exibir_anuncios, ad_slot_topo, ad_slot_meio, ad_slot_rodape,
      created_at, updated_at
    `, { count: 'exact' })
    .order('created_at', { ascending: false })
    .range(from, to)

  if (params.q) {
    const k = params.q.replace(/%/g, '')
    q = q.or(`display_name.ilike.%${k}%,title.ilike.%${k}%,slug.ilike.%${k}%,city.ilike.%${k}%`)
  }
  if (params.sector) q = q.eq('sector', params.sector)
  if (params.adsOnly) q = q.eq('exibir_anuncios', true)
  if (params.status) q = q.eq('status', params.status)

  const { data, error, count } = await q
  if (error) throw error
  return { data: (data ?? []) as Profile[], total: count ?? 0, page, perPage }
}

export async function listFeatured(limit = 12) {
  const supa = db()
  const { data, error } = await supa
    .from(TABLE)
    .select('id, slug, display_name, title, sector, cover_url, gallery_urls, exibir_anuncios, created_at')
    .eq('status', 'published')
    .order('created_at', { ascending: false })
    .limit(Math.max(1, Math.min(50, limit)))

  if (error) throw error
  return { data: data ?? [], total: data?.length ?? 0 }
}