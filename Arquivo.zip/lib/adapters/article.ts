// lib/adapters/article.ts
export type ParagraphBlock = { type: "paragraph"; text: string }
export type TipsBlock = { type: "tips"; title?: string; items: string[] }
export type CtaBlock = { type: "cta"; headline?: string; text?: string; button?: string }
export type ArticleBlock = ParagraphBlock | TipsBlock | CtaBlock

export type NormalizedArticle = {
  hook?: string
  content: ArticleBlock[]
}

const parseMaybe = <T,>(v: any, fallback: T): T => {
  if (v == null) return fallback
  if (typeof v === "string") {
    try { return JSON.parse(v) as T } catch { return fallback }
  }
  return v as T
}

/** Converte o JSON (ou string JSON) do artigo para blocos de UI. */
export function normalizeArticle(raw: any): NormalizedArticle | null {
  const article = parseMaybe<any>(raw, null)
  if (!article) return null

  const content: ArticleBlock[] = []

  // sections -> paragraphs (limpa vazios)
  if (Array.isArray(article.sections)) {
    for (const sec of article.sections) {
      const t = String(sec?.text ?? "").trim()
      if (t) content.push({ type: "paragraph", text: t })
    }
  }

  // tips -> bloco único
  if (Array.isArray(article.tips) && article.tips.length > 0) {
    const tips = article.tips.map((x: any) => String(x).trim()).filter(Boolean)
    if (tips.length) content.push({ type: "tips", items: tips })
  }

  // CTA opcional
  const cta = article.cta
  if (cta && (cta.headline || cta.text || cta.button)) {
    content.push({
      type: "cta",
      headline: cta.headline ? String(cta.headline) : undefined,
      text: cta.text ? String(cta.text) : undefined,
      button: cta.button ? String(cta.button) : undefined,
    })
  }

  if (!content.length) return null
  return { hook: article.hook ? String(article.hook) : undefined, content }
}